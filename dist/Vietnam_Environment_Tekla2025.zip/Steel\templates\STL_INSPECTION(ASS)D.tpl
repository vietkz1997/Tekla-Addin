template _tmp_0
{
    name = "tpled_template1";
    type = GRAPHICAL;
    width = 210;
    maxheight = 297.15;
    columns = (1, 1);
    gap = 5;
    fillpolicy = EVEN;
    filldirection = HORIZONTAL;
    fillstartfrom = TOPLEFT;
    margins = (0, 0, 0, 0);
    gridxspacing = 1;
    gridyspacing = 1;
    version = 3.6;
    created = "14.08.2018 00:30";
    modified = "13.09.2018 00:24";
    notes = "";

    pageheader _tmp_726
    {
        name = "PageHeader";
        height = 67;
        outputpolicy = NONE;

        lineorarc _tmp_1122
        {
            name = "LineOrArc_i0";
            x1 = 210;
            y1 = 62;
            x2 = 210;
            y2 = 67;
            pen = -1;
            color = 0;
            linetype = 1;
            linewidth = 1;
            bulge = 0;
        };

        lineorarc _tmp_41
        {
            name = "LineOrArc";
            x1 = 200;
            y1 = 36;
            x2 = 10;
            y2 = 36;
            pen = -1;
            color = 153;
            linetype = 1;
            linewidth = 1;
            bulge = 0;
        };

        lineorarc _tmp_42
        {
            name = "LineOrArc_i1";
            x1 = 200;
            y1 = 27;
            x2 = 10;
            y2 = 27;
            pen = -1;
            color = 153;
            linetype = 1;
            linewidth = 1;
            bulge = 0;
        };

        lineorarc _tmp_43
        {
            name = "LineOrArc_i2";
            x1 = 200;
            y1 = 18;
            x2 = 10;
            y2 = 18;
            pen = -1;
            color = 153;
            linetype = 1;
            linewidth = 1;
            bulge = 0;
        };

        lineorarc _tmp_44
        {
            name = "LineOrArc_i3";
            x1 = 200;
            y1 = 9;
            x2 = 10;
            y2 = 9;
            pen = -1;
            color = 153;
            linetype = 1;
            linewidth = 1;
            bulge = 0;
        };

        lineorarc _tmp_45
        {
            name = "LineOrArc_i5";
            x1 = 150;
            y1 = 54;
            x2 = 150;
            y2 = 0;
            pen = -1;
            color = 153;
            linetype = 1;
            linewidth = 1;
            bulge = 0;
        };

        lineorarc _tmp_46
        {
            name = "LineOrArc_i6";
            x1 = 180;
            y1 = 36;
            x2 = 180;
            y2 = 0;
            pen = -1;
            color = 153;
            linetype = 1;
            linewidth = 1;
            bulge = 0;
        };

        lineorarc _tmp_47
        {
            name = "LineOrArc_i7";
            x1 = 200;
            y1 = 45;
            x2 = 150;
            y2 = 45;
            pen = -1;
            color = 153;
            linetype = 1;
            linewidth = 1;
            bulge = 0;
        };

        lineorarc _tmp_48
        {
            name = "LineOrArc_i8";
            x1 = 31;
            y1 = 36;
            x2 = 31;
            y2 = 0;
            pen = -1;
            color = 153;
            linetype = 1;
            linewidth = 1;
            bulge = 0;
        };

        lineorarc _tmp_49
        {
            name = "LineOrArc_i9";
            x1 = 106;
            y1 = 36;
            x2 = 106;
            y2 = 0;
            pen = -1;
            color = 153;
            linetype = 1;
            linewidth = 1;
            bulge = 0;
        };

        lineorarc _tmp_50
        {
            name = "LineOrArc_i10";
            x1 = 60;
            y1 = 54;
            x2 = 60;
            y2 = 36;
            pen = -1;
            color = 153;
            linetype = 1;
            linewidth = 1;
            bulge = 0;
        };

        text _tmp_51
        {
            name = "(INSPECTION REPORT)";
            x1 = 86.0719131614654;
            y1 = 39.324892909344;
            x2 = 86.0719131614654;
            y2 = 39.324892909344;
            string = "(INSPECTION REPORT)";
            fontname = "����";
            fontcolor = 153;
            fonttype = 2;
            fontsize = 2.5;
            fontratio = 1;
            fontslant = 0;
            fontstyle = 0;
            angle = 0;
            justify = LEFT;
            pen = -1;
        };

        text _tmp_52
        {
            name = "SIGNATURE";
            x1 = 155.24762550882;
            y1 = 30.25;
            x2 = 155.24762550882;
            y2 = 30.25;
            string = "SIGNATURE";
            fontname = "����";
            fontcolor = 153;
            fonttype = 2;
            fontsize = 2.5;
            fontratio = 1;
            fontslant = 0;
            fontstyle = 0;
            angle = 0;
            justify = LEFT;
            pen = -1;
        };

        text _tmp_53
        {
            name = "DATE";
            x1 = 185.47829036635;
            y1 = 30.25;
            x2 = 185.47829036635;
            y2 = 30.25;
            string = "DATE";
            fontname = "����";
            fontcolor = 153;
            fonttype = 2;
            fontsize = 2.5;
            fontratio = 1;
            fontslant = 0;
            fontstyle = 0;
            angle = 0;
            justify = LEFT;
            pen = -1;
        };

        text _tmp_54
        {
            name = "INSPECTED BY";
            x1 = 115.603459972863;
            y1 = 30.25;
            x2 = 115.603459972863;
            y2 = 30.25;
            string = "INSPECTED BY";
            fontname = "����";
            fontcolor = 153;
            fonttype = 2;
            fontsize = 2.5;
            fontratio = 1;
            fontslant = 0;
            fontstyle = 0;
            angle = 0;
            justify = LEFT;
            pen = -1;
        };

        text _tmp_55
        {
            name = "PROJECT";
            x1 = 12.7235413839891;
            y1 = 30.25;
            x2 = 12.7235413839891;
            y2 = 30.25;
            string = "PROJECT";
            fontname = "����";
            fontcolor = 153;
            fonttype = 2;
            fontsize = 2.5;
            fontratio = 1;
            fontslant = 0;
            fontstyle = 0;
            angle = 0;
            justify = LEFT;
            pen = -1;
        };

        text _tmp_56
        {
            name = "AREA";
            x1 = 15.9308005427408;
            y1 = 21.25;
            x2 = 15.9308005427408;
            y2 = 21.25;
            string = "AREA";
            fontname = "����";
            fontcolor = 153;
            fonttype = 2;
            fontsize = 2.5;
            fontratio = 1;
            fontslant = 0;
            fontstyle = 0;
            angle = 0;
            justify = LEFT;
            pen = -1;
        };

        text _tmp_57
        {
            name = "ITEM NO.";
            x1 = 12.7981682496608;
            y1 = 12.25;
            x2 = 12.7981682496608;
            y2 = 12.25;
            string = "ITEM NO.";
            fontname = "����";
            fontcolor = 153;
            fonttype = 2;
            fontsize = 2.5;
            fontratio = 1;
            fontslant = 0;
            fontstyle = 0;
            angle = 0;
            justify = LEFT;
            pen = -1;
        };

        text _tmp_58
        {
            name = "CUSTOMER";
            x1 = 10.9087516960651;
            y1 = 3.25;
            x2 = 10.9087516960651;
            y2 = 3.25;
            string = "CUSTOMER";
            fontname = "����";
            fontcolor = 153;
            fonttype = 2;
            fontsize = 2.5;
            fontratio = 1;
            fontslant = 0;
            fontstyle = 0;
            angle = 0;
            justify = LEFT;
            pen = -1;
        };

        text _tmp_59
        {
            name = "ġ���˻纸����";
            x1 = 80.685210312076;
            y1 = 44.7796010648422;
            x2 = 80.685210312076;
            y2 = 44.7796010648422;
            string = "ġ���˻纸����";
            fontname = "����";
            fontcolor = 153;
            fonttype = 2;
            fontsize = 5;
            fontratio = 1;
            fontslant = 0;
            fontstyle = 0;
            angle = 0;
            justify = LEFT;
            pen = -1;
        };

        lineorarc _tmp_60
        {
            name = "LineOrArc_1";
            x1 = 200;
            y1 = 0;
            x2 = 200;
            y2 = 54;
            pen = -1;
            color = 153;
            linetype = 1;
            linewidth = 1;
            bulge = 0;
        };

        lineorarc _tmp_61
        {
            name = "LineOrArc_2";
            x1 = 200;
            y1 = 54;
            x2 = 10;
            y2 = 54;
            pen = -1;
            color = 153;
            linetype = 1;
            linewidth = 1;
            bulge = 0;
        };

        lineorarc _tmp_62
        {
            name = "LineOrArc_3";
            x1 = 10;
            y1 = 54;
            x2 = 10;
            y2 = 0;
            pen = -1;
            color = 153;
            linetype = 1;
            linewidth = 1;
            bulge = 0;
        };

        valuefield _tmp_63
        {
            name = "PROJECT.NAME_field";
            location = (35, 30.25);
            formula = "GetValue(\"PROJECT.NAME\")";
            maxnumoflines = 1;
            datatype = STRING;
            class = "";
            cacheable = TRUE;
            formatzeroasempty = FALSE;
            justify = LEFT;
            visibility = TRUE;
            angle = 0;
            length = 40;
            decimals = 2;
            sortdirection = NONE;
            fontname = "����";
            fontcolor = 153;
            fonttype = 2;
            fontsize = 2.5;
            fontratio = 1;
            fontstyle = 0;
            fontslant = 0;
            pen = -1;
            oncombine = NONE;
        };

        valuefield _tmp_64
        {
            name = "DRAWING.TITLE3_field";
            location = (35, 12.25);
            formula = "GetValue(\"DRAWING.TITLE3\")";
            datatype = STRING;
            class = "";
            cacheable = TRUE;
            justify = LEFT;
            visibility = TRUE;
            angle = 0;
            length = 40;
            decimals = 2;
            sortdirection = NONE;
            fontname = "����";
            fontcolor = 153;
            fonttype = 2;
            fontsize = 2.5;
            fontratio = 1;
            fontstyle = 0;
            fontslant = 0;
            pen = -1;
            oncombine = NONE;
        };

        valuefield _tmp_65
        {
            name = "PROJECT.INFO1_field";
            location = (35, 3.25);
            formula = "GetValue(\"PROJECT.INFO1\") + GetValue(\"DRAWING.NAME\")";
            datatype = STRING;
            class = "";
            cacheable = TRUE;
            formatzeroasempty = TRUE;
            justify = LEFT;
            visibility = TRUE;
            angle = 0;
            length = 40;
            decimals = 2;
            sortdirection = NONE;
            fontname = "����";
            fontcolor = 153;
            fonttype = 2;
            fontsize = 2.5;
            fontratio = 1;
            fontstyle = 0;
            fontslant = 0;
            pen = -1;
            oncombine = NONE;
        };

        valuefield _tmp_66
        {
            name = "PJ_USERFIELD_1_field";
            location = (112, 21.25);
            formula = "GetValue(\"PROJECT.USERDEFINED.PROJECT_USERFIELD_1\")";
            datatype = STRING;
            class = "";
            cacheable = TRUE;
            formatzeroasempty = TRUE;
            justify = CENTERED;
            visibility = TRUE;
            angle = 0;
            length = 20;
            decimals = 2;
            sortdirection = NONE;
            fontname = "����";
            fontcolor = 153;
            fonttype = 2;
            fontsize = 2.5;
            fontratio = 1;
            fontstyle = 0;
            fontslant = 0;
            pen = -1;
            oncombine = NONE;
        };

        lineorarc _tmp_67
        {
            name = "LineOrArc_42";
            x1 = 128;
            y1 = 19;
            x2 = 128;
            y2 = 19;
            pen = -1;
            color = 164;
            linetype = 1;
            linewidth = 1;
            bulge = 0;
        };

        valuefield _tmp_68
        {
            name = "PJ_USERFIELD_2_field";
            location = (112, 12.25);
            formula = "GetValue(\"PROJECT.USERDEFINED.PROJECT_USERFIELD_2\")";
            datatype = STRING;
            class = "";
            cacheable = TRUE;
            formatzeroasempty = TRUE;
            justify = CENTERED;
            visibility = TRUE;
            angle = 0;
            length = 20;
            decimals = 2;
            sortdirection = NONE;
            fontname = "����";
            fontcolor = 153;
            fonttype = 2;
            fontsize = 2.5;
            fontratio = 1;
            fontstyle = 0;
            fontslant = 0;
            pen = -1;
            oncombine = NONE;
        };

        valuefield _tmp_69
        {
            name = "PJ_USERFIELD_3_field";
            location = (112, 3.25);
            formula = "GetValue(\"PROJECT.USERDEFINED.PROJECT_USERFIELD_3\")";
            datatype = STRING;
            class = "";
            cacheable = TRUE;
            formatzeroasempty = TRUE;
            justify = CENTERED;
            visibility = TRUE;
            angle = 0;
            length = 20;
            decimals = 2;
            sortdirection = NONE;
            fontname = "����";
            fontcolor = 153;
            fonttype = 2;
            fontsize = 2.5;
            fontratio = 1;
            fontstyle = 0;
            fontslant = 0;
            pen = -1;
            oncombine = NONE;
        };

        valuefield _tmp_70
        {
            name = "PROJECT.OBJECT_field";
            location = (35, 21.25);
            formula = "GetValue(\"PROJECT.OBJECT\")";
            datatype = STRING;
            class = "";
            cacheable = TRUE;
            formatzeroasempty = TRUE;
            justify = LEFT;
            visibility = TRUE;
            angle = 0;
            length = 40;
            decimals = 2;
            sortdirection = NONE;
            fontname = "����";
            fontcolor = 153;
            fonttype = 2;
            fontsize = 2.5;
            fontratio = 1;
            fontstyle = 0;
            fontslant = 0;
            pen = -1;
            oncombine = NONE;
        };

        valuefield _tmp_71
        {
            name = "REV_CR_field";
            location = (157, 3.25);
            formula = "GetValue(\"REVISION.LAST_CREATED_BY\")";
            datatype = STRING;
            class = "";
            cacheable = TRUE;
            formatzeroasempty = TRUE;
            justify = CENTERED;
            visibility = TRUE;
            angle = 0;
            length = 10;
            decimals = 2;
            sortdirection = NONE;
            fontname = "����";
            fontcolor = 153;
            fonttype = 2;
            fontsize = 2.5;
            fontratio = 1;
            fontstyle = 0;
            fontslant = 0;
            pen = -1;
            oncombine = NONE;
        };

        valuefield _tmp_72
        {
            name = "REV_CH_field";
            location = (157, 12.25);
            formula = "GetValue(\"REVISION.LAST_CHECKED_BY\")";
            datatype = STRING;
            class = "";
            cacheable = TRUE;
            formatzeroasempty = TRUE;
            justify = CENTERED;
            visibility = TRUE;
            angle = 0;
            length = 10;
            decimals = 2;
            sortdirection = NONE;
            fontname = "����";
            fontcolor = 153;
            fonttype = 2;
            fontsize = 2.5;
            fontratio = 1;
            fontstyle = 0;
            fontslant = 0;
            pen = -1;
            oncombine = NONE;
        };

        valuefield _tmp_73
        {
            name = "REV_AP_field";
            location = (157, 21.25);
            formula = "GetValue(\"REVISION.LAST_APPROVED_BY\")";
            datatype = STRING;
            class = "";
            cacheable = TRUE;
            formatzeroasempty = TRUE;
            justify = CENTERED;
            visibility = TRUE;
            angle = 0;
            length = 10;
            decimals = 2;
            sortdirection = NONE;
            fontname = "����";
            fontcolor = 153;
            fonttype = 2;
            fontsize = 2.5;
            fontratio = 1;
            fontstyle = 0;
            fontslant = 0;
            pen = -1;
            oncombine = NONE;
        };

        valuefield _tmp_74
        {
            name = "AP_field";
            location = (182, 21.25);
            formula = "GetValue(\"REVISION.LAST_DATE_APPROVED\")";
            datatype = INTEGER;
            class = "Date";
            cacheable = TRUE;
            formatzeroasempty = TRUE;
            justify = CENTERED;
            visibility = TRUE;
            angle = 0;
            length = 10;
            decimals = 0;
            sortdirection = NONE;
            fontname = "����";
            fontcolor = 153;
            fonttype = 2;
            fontsize = 2.5;
            fontratio = 1;
            fontstyle = 0;
            fontslant = 0;
            pen = -1;
            oncombine = NONE;
            unit = "dd.mm.yyyy";
        };

        valuefield _tmp_75
        {
            name = "CH_field";
            location = (182, 12.25);
            formula = "GetValue(\"REVISION.LAST_DATE_CHECKED\")";
            datatype = INTEGER;
            class = "Date";
            cacheable = TRUE;
            formatzeroasempty = TRUE;
            justify = CENTERED;
            visibility = TRUE;
            angle = 0;
            length = 10;
            decimals = 0;
            sortdirection = NONE;
            fontname = "����";
            fontcolor = 153;
            fonttype = 2;
            fontsize = 2.5;
            fontratio = 1;
            fontstyle = 0;
            fontslant = 0;
            pen = -1;
            oncombine = NONE;
            unit = "dd.mm.yyyy";
        };

        valuefield _tmp_76
        {
            name = "CR_field";
            location = (182, 3.25);
            formula = "GetValue(\"REVISION.LAST_DATE_CREATE\")";
            datatype = INTEGER;
            class = "Date";
            cacheable = TRUE;
            formatzeroasempty = TRUE;
            justify = CENTERED;
            visibility = TRUE;
            angle = 0;
            length = 10;
            decimals = 0;
            sortdirection = NONE;
            fontname = "����";
            fontcolor = 153;
            fonttype = 2;
            fontsize = 2.5;
            fontratio = 1;
            fontstyle = 0;
            fontslant = 0;
            pen = -1;
            oncombine = NONE;
            unit = "dd.mm.yyyy";
        };

        valuefield _tmp_77
        {
            name = "Page_field";
            location = (162, 39.25);
            formula = "if (find(GetValue(\"DRAWING.NAME\"), \" - 100]\")) > -1 then\r\n    \"Page : 1 of \"\r\nelse\r\n    if (find(GetValue(\"DRAWING.NAME\"), \" - 101]\")) > -1 then\r\n        \"Page : 2 of \"\r\n    else\r\n        if (find(GetValue(\"DRAWING.NAME\"), \" - 102]\")) > -1 then\r\n            \"Page : 3 of \"\r\n        else\r\n            if (find(GetValue(\"DRAWING.NAME\"), \" - 103]\")) > -1 then\r\n                \"Page : 4 of \"\r\n            else\r\n                \"Page : 5 of \"\r\n            endif\r\n        endif\r\n    endif\r\nendif\r\n+ string(ceil(GetValue(\"NUMBER\") / 10), 0)";
            datatype = STRING;
            class = "";
            cacheable = TRUE;
            formatzeroasempty = TRUE;
            justify = CENTERED;
            visibility = TRUE;
            angle = 0;
            length = 20;
            decimals = 0;
            sortdirection = NONE;
            fontname = "����";
            fontcolor = 153;
            fonttype = 2;
            fontsize = 2.5;
            fontratio = 1;
            fontstyle = 0;
            fontslant = 0;
            pen = -1;
            oncombine = NONE;
        };

        valuefield _tmp_78
        {
            name = "Report_NO";
            location = (151, 48.25);
            formula = "\"Report NO. : \" + GetValue(\"DRAWING.TITLE2\")";
            datatype = STRING;
            class = "";
            cacheable = TRUE;
            formatzeroasempty = TRUE;
            justify = CENTERED;
            visibility = TRUE;
            angle = 0;
            length = 30;
            decimals = 2;
            sortdirection = NONE;
            fontname = "����";
            fontcolor = 153;
            fonttype = 2;
            fontsize = 2.5;
            fontratio = 1;
            fontstyle = 0;
            fontslant = 0;
            pen = -1;
            oncombine = NONE;
        };

        picture _tmp_79
        {
            name = "Picture";
            file = "Tekla_Structures_logo2.png";
            refpoint = (10, 36);
            height = 18;
            width = 50;
            keepaspect = TRUE;
            fitinside = TRUE;
        };

        lineorarc _tmp_80
        {
            name = "LineOrArc_i4";
            x1 = 200;
            y1 = 0;
            x2 = 10;
            y2 = 0;
            pen = -1;
            color = 153;
            linetype = 1;
            linewidth = 1;
            bulge = 0;
        };

        lineorarc _tmp_81
        {
            name = "LineOrArc_43";
            x1 = 210;
            y1 = 67;
            x2 = 205;
            y2 = 67;
            pen = -1;
            color = 0;
            linetype = 1;
            linewidth = 1;
            bulge = 0;
        };
    };

    row _tmp_2
    {
        name = "DRAWING";
        height = 81.4499999999999;
        visibility = TRUE;
        usecolumns = FALSE;
        rule = "";
        contenttype = "DRAWING";
        sorttype = COMBINE;

        polyline _tmp_1193
        {
            name = "Polyline_i0";
            filled = FALSE;
            filltype = -1;
            color = 153;
            linetype = 1;
            linewidth = 1;
            pen = -1;

            lineorarc _tmp_1194
            {
                name = "LineOrArc_i1";
                x1 = 10;
                y1 = 0;
                x2 = 200;
                y2 = 0;
                pen = -1;
                color = 153;
                linetype = 1;
                linewidth = 1;
                bulge = 0;
            };

            lineorarc _tmp_1195
            {
                name = "LineOrArc_i1";
                x1 = 200;
                y1 = 0;
                x2 = 200;
                y2 = 81.4499999999999;
                pen = -1;
                color = 153;
                linetype = 1;
                linewidth = 1;
                bulge = 0;
            };

            lineorarc _tmp_1196
            {
                name = "LineOrArc_i1";
                x1 = 200;
                y1 = 81.4499999999999;
                x2 = 10;
                y2 = 81.4499999999999;
                pen = -1;
                color = 153;
                linetype = 1;
                linewidth = 1;
                bulge = 0;
            };

            lineorarc _tmp_1197
            {
                name = "LineOrArc_i1";
                x1 = 10;
                y1 = 81.4499999999999;
                x2 = 10;
                y2 = 0;
                pen = -1;
                color = 153;
                linetype = 1;
                linewidth = 1;
                bulge = 0;
            };
        };
    };

    pagefooter _tmp_810
    {
        name = "PageFooter";
        height = 148.7;
        outputpolicy = NONE;

        lineorarc _tmp_1027
        {
            name = "LineOrArc_13";
            x1 = 200;
            y1 = 41.45;
            x2 = 10;
            y2 = 41.45;
            pen = -1;
            color = 153;
            linetype = 1;
            linewidth = 1;
            bulge = 0;
        };

        lineorarc _tmp_1028
        {
            name = "LineOrArc_14";
            x1 = 170;
            y1 = 34.3;
            x2 = 10;
            y2 = 34.3;
            pen = -1;
            color = 153;
            linetype = 1;
            linewidth = 1;
            bulge = 0;
        };

        lineorarc _tmp_1029
        {
            name = "LineOrArc_15";
            x1 = 200;
            y1 = 27.15;
            x2 = 10;
            y2 = 27.15;
            pen = -1;
            color = 153;
            linetype = 1;
            linewidth = 1;
            bulge = 0;
        };

        lineorarc _tmp_1030
        {
            name = "LineOrArc_16";
            x1 = 170;
            y1 = 20;
            x2 = 10;
            y2 = 20;
            pen = -1;
            color = 153;
            linetype = 1;
            linewidth = 1;
            bulge = 0;
        };

        lineorarc _tmp_1031
        {
            name = "LineOrArc_17";
            x1 = 170;
            y1 = 12.85;
            x2 = 10;
            y2 = 12.85;
            pen = -1;
            color = 153;
            linetype = 1;
            linewidth = 1;
            bulge = 0;
        };

        lineorarc _tmp_1042
        {
            name = "LineOrArc_i25";
            x1 = 65;
            y1 = 34.3;
            x2 = 65;
            y2 = 5.7;
            pen = -1;
            color = 153;
            linetype = 1;
            linewidth = 1;
            bulge = 0;
        };

        lineorarc _tmp_1044
        {
            name = "LineOrArc_i27";
            x1 = 86;
            y1 = 34.3;
            x2 = 86;
            y2 = 5.7;
            pen = -1;
            color = 153;
            linetype = 1;
            linewidth = 1;
            bulge = 0;
        };

        lineorarc _tmp_1048
        {
            name = "LineOrArc_i31";
            x1 = 149;
            y1 = 34.3;
            x2 = 149;
            y2 = 5.7;
            pen = -1;
            color = 153;
            linetype = 1;
            linewidth = 1;
            bulge = 0;
        };

        text _tmp_1055
        {
            name = "�����˻�CHECKLIST";
            x1 = 72.3931478968792;
            y1 = 36.625;
            x2 = 72.3931478968792;
            y2 = 36.625;
            string = "�����˻� CHECK LIST";
            fontname = "����";
            fontcolor = 153;
            fonttype = 2;
            fontsize = 2.5;
            fontratio = 1;
            fontslant = 0;
            fontstyle = 0;
            angle = 0;
            justify = LEFT;
            pen = -1;
        };

        text _tmp_1056
        {
            name = "�������";
            x1 = 178.052917232022;
            y1 = 33.05;
            x2 = 178.052917232022;
            y2 = 33.05;
            string = "�������";
            fontname = "����";
            fontcolor = 153;
            fonttype = 2;
            fontsize = 2.5;
            fontratio = 1;
            fontslant = 0;
            fontstyle = 0;
            angle = 0;
            justify = LEFT;
            pen = -1;
        };

        text _tmp_1057
        {
            name = "ACC";
            x1 = 181.338195386703;
            y1 = 15.175;
            x2 = 181.338195386703;
            y2 = 15.175;
            string = "ACC";
            fontname = "����";
            fontcolor = 153;
            fonttype = 2;
            fontsize = 2.5;
            fontratio = 1;
            fontslant = 0;
            fontstyle = 0;
            angle = 0;
            justify = LEFT;
            pen = -1;
        };

        text _tmp_1058
        {
            name = "�˻��׸�";
            x1 = 30.5529172320217;
            y1 = 29.475;
            x2 = 30.5529172320217;
            y2 = 29.475;
            string = "�˻��׸�";
            fontname = "����";
            fontcolor = 153;
            fonttype = 2;
            fontsize = 2.5;
            fontratio = 1;
            fontslant = 0;
            fontstyle = 0;
            angle = 0;
            justify = LEFT;
            pen = -1;
        };

        text _tmp_1059
        {
            name = "���";
            x1 = 72.0264586160109;
            y1 = 29.475;
            x2 = 72.0264586160109;
            y2 = 29.475;
            string = "���";
            fontname = "����";
            fontcolor = 153;
            fonttype = 2;
            fontsize = 2.5;
            fontratio = 1;
            fontslant = 0;
            fontstyle = 0;
            angle = 0;
            justify = LEFT;
            pen = -1;
        };

        text _tmp_1060
        {
            name = "�˻��׸�1";
            x1 = 110.552917232022;
            y1 = 29.475;
            x2 = 110.552917232022;
            y2 = 29.475;
            string = "�˻��׸�";
            fontname = "����";
            fontcolor = 153;
            fonttype = 2;
            fontsize = 2.5;
            fontratio = 1;
            fontslant = 0;
            fontstyle = 0;
            angle = 0;
            justify = LEFT;
            pen = -1;
        };

        text _tmp_1061
        {
            name = "���1";
            x1 = 156.026458616011;
            y1 = 29.475;
            x2 = 156.026458616011;
            y2 = 29.475;
            string = "���";
            fontname = "����";
            fontcolor = 153;
            fonttype = 2;
            fontsize = 2.5;
            fontratio = 1;
            fontslant = 0;
            fontstyle = 0;
            angle = 0;
            justify = LEFT;
            pen = -1;
        };

        text _tmp_1062
        {
            name = "Note1";
            x1 = 11.3956432217324;
            y1 = 22.325;
            x2 = 11.3956432217324;
            y2 = 22.325;
            string = "1. ���ǥ���� ��ö���´� ��ȣ�Ѱ�?";
            fontname = "����";
            fontcolor = 153;
            fonttype = 2;
            fontsize = 2.5;
            fontratio = 0.9;
            fontslant = 0;
            fontstyle = 0;
            angle = 0;
            justify = LEFT;
            pen = -1;
        };

        text _tmp_1063
        {
            name = "Note2";
            x1 = 11.3956432217324;
            y1 = 15.175;
            x2 = 11.3956432217324;
            y2 = 15.175;
            string = "2. Undercut�� ���� �Ǿ��°�?";
            fontname = "����";
            fontcolor = 153;
            fonttype = 2;
            fontsize = 2.5;
            fontratio = 0.9;
            fontslant = 0;
            fontstyle = 0;
            angle = 0;
            justify = LEFT;
            pen = -1;
        };

        text _tmp_1064
        {
            name = "Note3";
            x1 = 11.3956432217324;
            y1 = 8.025;
            x2 = 11.3956432217324;
            y2 = 8.025;
            string = "3. Overlap�� �����Ǿ��°� ?    ";
            fontname = "����";
            fontcolor = 153;
            fonttype = 2;
            fontsize = 2.5;
            fontratio = 0.9;
            fontslant = 0;
            fontstyle = 0;
            angle = 0;
            justify = LEFT;
            pen = -1;
        };

        text _tmp_1065
        {
            name = "Note4";
            x1 = 87.3956432217324;
            y1 = 22.325;
            x2 = 87.3956432217324;
            y2 = 22.325;
            string = "4. Spatter, Slag ���� ���´� ��ȣ�Ѱ�?      ";
            fontname = "����";
            fontcolor = 153;
            fonttype = 2;
            fontsize = 2.5;
            fontratio = 0.9;
            fontslant = 0;
            fontstyle = 0;
            angle = 0;
            justify = LEFT;
            pen = -1;
        };

        text _tmp_1066
        {
            name = "Note5";
            x1 = 87.3956432217324;
            y1 = 15.175;
            x2 = 87.3956432217324;
            y2 = 15.175;
            string = "5. ������ ������ ��ȣ�Ѱ�?      ";
            fontname = "����";
            fontcolor = 153;
            fonttype = 2;
            fontsize = 2.5;
            fontratio = 0.9;
            fontslant = 0;
            fontstyle = 0;
            angle = 0;
            justify = LEFT;
            pen = -1;
        };

        text _tmp_1067
        {
            name = "Note6";
            x1 = 87.3956432217324;
            y1 = 8.025;
            x2 = 87.3956432217324;
            y2 = 8.025;
            string = "6. ���������� ����� ��ġ�ϴ°�?      ";
            fontname = "����";
            fontcolor = 153;
            fonttype = 2;
            fontsize = 2.5;
            fontratio = 0.9;
            fontslant = 0;
            fontstyle = 0;
            angle = 0;
            justify = LEFT;
            pen = -1;
        };

        text _tmp_1068
        {
            name = "OK";
            x1 = 73.0576662143826;
            y1 = 22.325;
            x2 = 73.0576662143826;
            y2 = 22.325;
            string = "OK";
            fontname = "����";
            fontcolor = 153;
            fonttype = 2;
            fontsize = 2.5;
            fontratio = 1;
            fontslant = 0;
            fontstyle = 0;
            angle = 0;
            justify = LEFT;
            pen = -1;
        };

        text _tmp_1069
        {
            name = "OK_1";
            x1 = 73.0576662143826;
            y1 = 15.175;
            x2 = 73.0576662143826;
            y2 = 15.175;
            string = "OK";
            fontname = "����";
            fontcolor = 153;
            fonttype = 2;
            fontsize = 2.5;
            fontratio = 1;
            fontslant = 0;
            fontstyle = 0;
            angle = 0;
            justify = LEFT;
            pen = -1;
        };

        text _tmp_1070
        {
            name = "OK_2";
            x1 = 73.0576662143826;
            y1 = 8.025;
            x2 = 73.0576662143826;
            y2 = 8.025;
            string = "OK";
            fontname = "����";
            fontcolor = 153;
            fonttype = 2;
            fontsize = 2.5;
            fontratio = 1;
            fontslant = 0;
            fontstyle = 0;
            angle = 0;
            justify = LEFT;
            pen = -1;
        };

        text _tmp_1071
        {
            name = "OK_3";
            x1 = 157.057666214383;
            y1 = 22.325;
            x2 = 157.057666214383;
            y2 = 22.325;
            string = "OK";
            fontname = "����";
            fontcolor = 153;
            fonttype = 2;
            fontsize = 2.5;
            fontratio = 1;
            fontslant = 0;
            fontstyle = 0;
            angle = 0;
            justify = LEFT;
            pen = -1;
        };

        text _tmp_1072
        {
            name = "OK_4";
            x1 = 157.057666214383;
            y1 = 15.175;
            x2 = 157.057666214383;
            y2 = 15.175;
            string = "OK";
            fontname = "����";
            fontcolor = 153;
            fonttype = 2;
            fontsize = 2.5;
            fontratio = 1;
            fontslant = 0;
            fontstyle = 0;
            angle = 0;
            justify = LEFT;
            pen = -1;
        };

        text _tmp_1073
        {
            name = "OK_5";
            x1 = 157.057666214383;
            y1 = 8.025;
            x2 = 157.057666214383;
            y2 = 8.025;
            string = "OK";
            fontname = "����";
            fontcolor = 153;
            fonttype = 2;
            fontsize = 2.5;
            fontratio = 1;
            fontslant = 0;
            fontstyle = 0;
            angle = 0;
            justify = LEFT;
            pen = -1;
        };

        lineorarc _tmp_1074
        {
            name = "LineOrArc_22";
            x1 = 179;
            y1 = 141.55;
            x2 = 32;
            y2 = 141.55;
            pen = -1;
            color = 153;
            linetype = 1;
            linewidth = 1;
            bulge = 0;
        };

        lineorarc _tmp_1075
        {
            name = "LineOrArc_23";
            x1 = 179;
            y1 = 148.7;
            x2 = 179;
            y2 = 134.4;
            pen = -1;
            color = 153;
            linetype = 1;
            linewidth = 1;
            bulge = 0;
        };

        lineorarc _tmp_1076
        {
            name = "LineOrArc_24";
            x1 = 158;
            y1 = 148.7;
            x2 = 158;
            y2 = 134.4;
            pen = -1;
            color = 153;
            linetype = 1;
            linewidth = 1;
            bulge = 0;
        };

        lineorarc _tmp_1077
        {
            name = "LineOrArc_25";
            x1 = 137;
            y1 = 148.7;
            x2 = 137;
            y2 = 134.4;
            pen = -1;
            color = 153;
            linetype = 1;
            linewidth = 1;
            bulge = 0;
        };

        lineorarc _tmp_1078
        {
            name = "LineOrArc_26";
            x1 = 116;
            y1 = 148.7;
            x2 = 116;
            y2 = 134.4;
            pen = -1;
            color = 153;
            linetype = 1;
            linewidth = 1;
            bulge = 0;
        };

        lineorarc _tmp_1079
        {
            name = "LineOrArc_27";
            x1 = 95;
            y1 = 148.7;
            x2 = 95;
            y2 = 134.4;
            pen = -1;
            color = 153;
            linetype = 1;
            linewidth = 1;
            bulge = 0;
        };

        lineorarc _tmp_1080
        {
            name = "LineOrArc_28";
            x1 = 74;
            y1 = 148.7;
            x2 = 74;
            y2 = 134.4;
            pen = -1;
            color = 153;
            linetype = 1;
            linewidth = 1;
            bulge = 0;
        };

        lineorarc _tmp_1081
        {
            name = "LineOrArc_29";
            x1 = 53;
            y1 = 148.7;
            x2 = 53;
            y2 = 134.4;
            pen = -1;
            color = 153;
            linetype = 1;
            linewidth = 1;
            bulge = 0;
        };

        lineorarc _tmp_1082
        {
            name = "LineOrArc_30";
            x1 = 32;
            y1 = 148.7;
            x2 = 32;
            y2 = 134.4;
            pen = -1;
            color = 153;
            linetype = 1;
            linewidth = 1;
            bulge = 0;
        };

        lineorarc _tmp_1083
        {
            name = "LineOrArc_31";
            x1 = 44;
            y1 = 141.55;
            x2 = 44;
            y2 = 134.4;
            pen = -1;
            color = 153;
            linetype = 1;
            linewidth = 1;
            bulge = 0;
        };

        lineorarc _tmp_1084
        {
            name = "LineOrArc_32";
            x1 = 10;
            y1 = 148.7;
            x2 = 32;
            y2 = 134.4;
            pen = -1;
            color = 153;
            linetype = 1;
            linewidth = 1;
            bulge = 0;
        };

        lineorarc _tmp_1085
        {
            name = "LineOrArc_33";
            x1 = 65;
            y1 = 141.55;
            x2 = 65;
            y2 = 134.4;
            pen = -1;
            color = 153;
            linetype = 1;
            linewidth = 1;
            bulge = 0;
        };

        lineorarc _tmp_1086
        {
            name = "LineOrArc_34";
            x1 = 86;
            y1 = 141.55;
            x2 = 86;
            y2 = 134.4;
            pen = -1;
            color = 153;
            linetype = 1;
            linewidth = 1;
            bulge = 0;
        };

        lineorarc _tmp_1087
        {
            name = "LineOrArc_35";
            x1 = 107;
            y1 = 141.55;
            x2 = 107;
            y2 = 134.4;
            pen = -1;
            color = 153;
            linetype = 1;
            linewidth = 1;
            bulge = 0;
        };

        lineorarc _tmp_1088
        {
            name = "LineOrArc_36";
            x1 = 128;
            y1 = 141.55;
            x2 = 128;
            y2 = 134.4;
            pen = -1;
            color = 153;
            linetype = 1;
            linewidth = 1;
            bulge = 0;
        };

        lineorarc _tmp_1089
        {
            name = "LineOrArc_37";
            x1 = 149;
            y1 = 141.55;
            x2 = 149;
            y2 = 134.4;
            pen = -1;
            color = 153;
            linetype = 1;
            linewidth = 1;
            bulge = 0;
        };

        lineorarc _tmp_1090
        {
            name = "LineOrArc_38";
            x1 = 170;
            y1 = 141.55;
            x2 = 170;
            y2 = 134.4;
            pen = -1;
            color = 153;
            linetype = 1;
            linewidth = 1;
            bulge = 0;
        };

        text _tmp_1091
        {
            name = "Text_14";
            x1 = 21.4923215712929;
            y1 = 143.875;
            x2 = 21.4923215712929;
            y2 = 143.875;
            string = "Mark";
            fontname = "����";
            fontcolor = 153;
            fonttype = 2;
            fontsize = 2.5;
            fontratio = 1;
            fontslant = 0;
            fontstyle = 0;
            angle = 0;
            justify = LEFT;
            pen = -1;
        };

        text _tmp_1092
        {
            name = "Text_15";
            x1 = 10.5547395001152;
            y1 = 136.725;
            x2 = 10.5547395001152;
            y2 = 136.725;
            string = "�����ȣ";
            fontname = "����";
            fontcolor = 153;
            fonttype = 2;
            fontsize = 2.5;
            fontratio = 1;
            fontslant = 0;
            fontstyle = 0;
            angle = 0;
            justify = LEFT;
            pen = -1;
        };

        text _tmp_1093
        {
            name = "Text_16";
            x1 = 41.4874491180461;
            y1 = 143.875;
            x2 = 41.4874491180461;
            y2 = 143.875;
            string = "A";
            fontname = "����";
            fontcolor = 153;
            fonttype = 2;
            fontsize = 2.5;
            fontratio = 1;
            fontslant = 0;
            fontstyle = 0;
            angle = 0;
            justify = LEFT;
            pen = -1;
        };

        text _tmp_1094
        {
            name = "Text_17";
            x1 = 34.4450474898236;
            y1 = 136.725;
            x2 = 34.4450474898236;
            y2 = 136.725;
            string = "Dwg";
            fontname = "����";
            fontcolor = 153;
            fonttype = 2;
            fontsize = 2.5;
            fontratio = 1;
            fontslant = 0;
            fontstyle = 0;
            angle = 0;
            justify = LEFT;
            pen = -1;
        };

        text _tmp_1095
        {
            name = "Text_18";
            x1 = 45.6506105834464;
            y1 = 136.725;
            x2 = 45.6506105834464;
            y2 = 136.725;
            string = "Diff";
            fontname = "����";
            fontcolor = 153;
            fonttype = 2;
            fontsize = 2.5;
            fontratio = 1;
            fontslant = 0;
            fontstyle = 0;
            angle = 0;
            justify = LEFT;
            pen = -1;
        };

        text _tmp_1096
        {
            name = "Text_19";
            x1 = 62.4586160108548;
            y1 = 143.875;
            x2 = 62.4586160108548;
            y2 = 143.875;
            string = "B";
            fontname = "����";
            fontcolor = 153;
            fonttype = 2;
            fontsize = 2.5;
            fontratio = 1;
            fontslant = 0;
            fontstyle = 0;
            angle = 0;
            justify = LEFT;
            pen = -1;
        };

        text _tmp_1097
        {
            name = "Text_20";
            x1 = 55.4450474898236;
            y1 = 136.725;
            x2 = 55.4450474898236;
            y2 = 136.725;
            string = "Dwg";
            fontname = "����";
            fontcolor = 153;
            fonttype = 2;
            fontsize = 2.5;
            fontratio = 1;
            fontslant = 0;
            fontstyle = 0;
            angle = 0;
            justify = LEFT;
            pen = -1;
        };

        text _tmp_1098
        {
            name = "Text_21";
            x1 = 66.6506105834464;
            y1 = 136.725;
            x2 = 66.6506105834464;
            y2 = 136.725;
            string = "Diff";
            fontname = "����";
            fontcolor = 153;
            fonttype = 2;
            fontsize = 2.5;
            fontratio = 1;
            fontslant = 0;
            fontstyle = 0;
            angle = 0;
            justify = LEFT;
            pen = -1;
        };

        text _tmp_1099
        {
            name = "Text_22";
            x1 = 83.5298507462687;
            y1 = 143.875;
            x2 = 83.5298507462687;
            y2 = 143.875;
            string = "C";
            fontname = "����";
            fontcolor = 153;
            fonttype = 2;
            fontsize = 2.5;
            fontratio = 1;
            fontslant = 0;
            fontstyle = 0;
            angle = 0;
            justify = LEFT;
            pen = -1;
        };

        text _tmp_1100
        {
            name = "Text_23";
            x1 = 76.4450474898236;
            y1 = 136.725;
            x2 = 76.4450474898236;
            y2 = 136.725;
            string = "Dwg";
            fontname = "����";
            fontcolor = 153;
            fonttype = 2;
            fontsize = 2.5;
            fontratio = 1;
            fontslant = 0;
            fontstyle = 0;
            angle = 0;
            justify = LEFT;
            pen = -1;
        };

        text _tmp_1101
        {
            name = "Text_24";
            x1 = 87.6506105834464;
            y1 = 136.725;
            x2 = 87.6506105834464;
            y2 = 136.725;
            string = "Diff";
            fontname = "����";
            fontcolor = 153;
            fonttype = 2;
            fontsize = 2.5;
            fontratio = 1;
            fontslant = 0;
            fontstyle = 0;
            angle = 0;
            justify = LEFT;
            pen = -1;
        };

        text _tmp_1102
        {
            name = "Text_25";
            x1 = 104.451831750339;
            y1 = 143.875;
            x2 = 104.451831750339;
            y2 = 143.875;
            string = "D";
            fontname = "����";
            fontcolor = 153;
            fonttype = 2;
            fontsize = 2.5;
            fontratio = 1;
            fontslant = 0;
            fontstyle = 0;
            angle = 0;
            justify = LEFT;
            pen = -1;
        };

        text _tmp_1103
        {
            name = "Text_26";
            x1 = 97.4450474898236;
            y1 = 136.725;
            x2 = 97.4450474898236;
            y2 = 136.725;
            string = "Dwg";
            fontname = "����";
            fontcolor = 153;
            fonttype = 2;
            fontsize = 2.5;
            fontratio = 1;
            fontslant = 0;
            fontstyle = 0;
            angle = 0;
            justify = LEFT;
            pen = -1;
        };

        text _tmp_1104
        {
            name = "Text_27";
            x1 = 108.650610583446;
            y1 = 136.725;
            x2 = 108.650610583446;
            y2 = 136.725;
            string = "Diff";
            fontname = "����";
            fontcolor = 153;
            fonttype = 2;
            fontsize = 2.5;
            fontratio = 1;
            fontslant = 0;
            fontstyle = 0;
            angle = 0;
            justify = LEFT;
            pen = -1;
        };

        text _tmp_1105
        {
            name = "Text_28";
            x1 = 125.529850746269;
            y1 = 143.875;
            x2 = 125.529850746269;
            y2 = 143.875;
            string = "E";
            fontname = "����";
            fontcolor = 153;
            fonttype = 2;
            fontsize = 2.5;
            fontratio = 1;
            fontslant = 0;
            fontstyle = 0;
            angle = 0;
            justify = LEFT;
            pen = -1;
        };

        text _tmp_1106
        {
            name = "Text_29";
            x1 = 118.445047489824;
            y1 = 136.725;
            x2 = 118.445047489824;
            y2 = 136.725;
            string = "Dwg";
            fontname = "����";
            fontcolor = 153;
            fonttype = 2;
            fontsize = 2.5;
            fontratio = 1;
            fontslant = 0;
            fontstyle = 0;
            angle = 0;
            justify = LEFT;
            pen = -1;
        };

        text _tmp_1107
        {
            name = "Text_30";
            x1 = 129.650610583446;
            y1 = 136.725;
            x2 = 129.650610583446;
            y2 = 136.725;
            string = "Diff";
            fontname = "����";
            fontcolor = 153;
            fonttype = 2;
            fontsize = 2.5;
            fontratio = 1;
            fontslant = 0;
            fontstyle = 0;
            angle = 0;
            justify = LEFT;
            pen = -1;
        };

        text _tmp_1108
        {
            name = "Text_31";
            x1 = 146.902985074627;
            y1 = 143.875;
            x2 = 146.902985074627;
            y2 = 143.875;
            string = "F";
            fontname = "����";
            fontcolor = 153;
            fonttype = 2;
            fontsize = 2.5;
            fontratio = 1;
            fontslant = 0;
            fontstyle = 0;
            angle = 0;
            justify = LEFT;
            pen = -1;
        };

        text _tmp_1109
        {
            name = "Text_32";
            x1 = 139.445047489824;
            y1 = 136.725;
            x2 = 139.445047489824;
            y2 = 136.725;
            string = "Dwg";
            fontname = "����";
            fontcolor = 153;
            fonttype = 2;
            fontsize = 2.5;
            fontratio = 1;
            fontslant = 0;
            fontstyle = 0;
            angle = 0;
            justify = LEFT;
            pen = -1;
        };

        text _tmp_1110
        {
            name = "Text_33";
            x1 = 150.650610583446;
            y1 = 136.725;
            x2 = 150.650610583446;
            y2 = 136.725;
            string = "Diff";
            fontname = "����";
            fontcolor = 153;
            fonttype = 2;
            fontsize = 2.5;
            fontratio = 1;
            fontslant = 0;
            fontstyle = 0;
            angle = 0;
            justify = LEFT;
            pen = -1;
        };

        text _tmp_1111
        {
            name = "Text_34";
            x1 = 167.462008141113;
            y1 = 143.875;
            x2 = 167.462008141113;
            y2 = 143.875;
            string = "G";
            fontname = "����";
            fontcolor = 153;
            fonttype = 2;
            fontsize = 2.5;
            fontratio = 1;
            fontslant = 0;
            fontstyle = 0;
            angle = 0;
            justify = LEFT;
            pen = -1;
        };

        text _tmp_1112
        {
            name = "Text_35";
            x1 = 160.445047489824;
            y1 = 136.725;
            x2 = 160.445047489824;
            y2 = 136.725;
            string = "Dwg";
            fontname = "����";
            fontcolor = 153;
            fonttype = 2;
            fontsize = 2.5;
            fontratio = 1;
            fontslant = 0;
            fontstyle = 0;
            angle = 0;
            justify = LEFT;
            pen = -1;
        };

        text _tmp_1113
        {
            name = "Text_36";
            x1 = 171.650610583446;
            y1 = 136.725;
            x2 = 171.650610583446;
            y2 = 136.725;
            string = "Diff";
            fontname = "����";
            fontcolor = 153;
            fonttype = 2;
            fontsize = 2.5;
            fontratio = 1;
            fontslant = 0;
            fontstyle = 0;
            angle = 0;
            justify = LEFT;
            pen = -1;
        };

        text _tmp_1114
        {
            name = "Text_37";
            x1 = 181.810040705563;
            y1 = 142.875;
            x2 = 181.810040705563;
            y2 = 142.875;
            string = "Dwg. No.";
            fontname = "����";
            fontcolor = 153;
            fonttype = 2;
            fontsize = 2.5;
            fontratio = 1;
            fontslant = 0;
            fontstyle = 0;
            angle = 0;
            justify = LEFT;
            pen = -1;
        };

        text _tmp_1115
        {
            name = "Text_38";
            x1 = 181.107869742198;
            y1 = 137.725;
            x2 = 181.107869742198;
            y2 = 137.725;
            string = "(Rev. No.)";
            fontname = "����";
            fontcolor = 153;
            fonttype = 2;
            fontsize = 2.5;
            fontratio = 1;
            fontslant = 0;
            fontstyle = 0;
            angle = 0;
            justify = LEFT;
            pen = -1;
        };

        lineorarc _tmp_1116
        {
            name = "LineOrArc_39";
            x1 = 10;
            y1 = 148.7;
            x2 = 10;
            y2 = 134.4;
            pen = -1;
            color = 153;
            linetype = 1;
            linewidth = 1;
            bulge = 0;
        };

        lineorarc _tmp_1117
        {
            name = "LineOrArc_40";
            x1 = 200;
            y1 = 148.7;
            x2 = 200;
            y2 = 134.4;
            pen = -1;
            color = 153;
            linetype = 1;
            linewidth = 1;
            bulge = 0;
        };

        lineorarc _tmp_1118
        {
            name = "LineOrArc_21";
            x1 = 200;
            y1 = 148.7;
            x2 = 10;
            y2 = 148.7;
            pen = -1;
            color = 153;
            linetype = 1;
            linewidth = 1;
            bulge = 0;
        };

        lineorarc _tmp_33
        {
            name = "LineOrArc_i33";
            x1 = 10;
            y1 = 112.95;
            x2 = 32;
            y2 = 98.6500000000001;
            pen = -1;
            color = 153;
            linetype = 1;
            linewidth = 1;
            bulge = 0;
        };

        text _tmp_34
        {
            name = "Mark";
            x1 = 21.4923215712929;
            y1 = 108.125;
            x2 = 21.4923215712929;
            y2 = 108.125;
            string = "Mark";
            fontname = "����";
            fontcolor = 153;
            fonttype = 2;
            fontsize = 2.5;
            fontratio = 1;
            fontslant = 0;
            fontstyle = 0;
            angle = 0;
            justify = LEFT;
            pen = -1;
        };

        text _tmp_35
        {
            name = "�����ȣ";
            x1 = 10.5547395001152;
            y1 = 100.975;
            x2 = 10.5547395001152;
            y2 = 100.975;
            string = "�����ȣ";
            fontname = "����";
            fontcolor = 153;
            fonttype = 2;
            fontsize = 2.5;
            fontratio = 1;
            fontslant = 0;
            fontstyle = 0;
            angle = 0;
            justify = LEFT;
            pen = -1;
        };

        text _tmp_36
        {
            name = "H";
            x1 = 41.4874491180461;
            y1 = 108.125;
            x2 = 41.4874491180461;
            y2 = 108.125;
            string = "H";
            fontname = "����";
            fontcolor = 153;
            fonttype = 2;
            fontsize = 2.5;
            fontratio = 1;
            fontslant = 0;
            fontstyle = 0;
            angle = 0;
            justify = LEFT;
            pen = -1;
        };

        text _tmp_37
        {
            name = "Dwg1";
            x1 = 34.4450474898236;
            y1 = 100.975;
            x2 = 34.4450474898236;
            y2 = 100.975;
            string = "Dwg";
            fontname = "����";
            fontcolor = 153;
            fonttype = 2;
            fontsize = 2.5;
            fontratio = 1;
            fontslant = 0;
            fontstyle = 0;
            angle = 0;
            justify = LEFT;
            pen = -1;
        };

        text _tmp_38
        {
            name = "Diff";
            x1 = 45.6506105834464;
            y1 = 100.975;
            x2 = 45.6506105834464;
            y2 = 100.975;
            string = "Diff";
            fontname = "����";
            fontcolor = 153;
            fonttype = 2;
            fontsize = 2.5;
            fontratio = 1;
            fontslant = 0;
            fontstyle = 0;
            angle = 0;
            justify = LEFT;
            pen = -1;
        };

        text _tmp_39
        {
            name = "I";
            x1 = 62.4586160108548;
            y1 = 108.125;
            x2 = 62.4586160108548;
            y2 = 108.125;
            string = "I";
            fontname = "����";
            fontcolor = 153;
            fonttype = 2;
            fontsize = 2.5;
            fontratio = 1;
            fontslant = 0;
            fontstyle = 0;
            angle = 0;
            justify = LEFT;
            pen = -1;
        };

        text _tmp_40
        {
            name = "Dwg_1";
            x1 = 55.4450474898236;
            y1 = 100.975;
            x2 = 55.4450474898236;
            y2 = 100.975;
            string = "Dwg";
            fontname = "����";
            fontcolor = 153;
            fonttype = 2;
            fontsize = 2.5;
            fontratio = 1;
            fontslant = 0;
            fontstyle = 0;
            angle = 0;
            justify = LEFT;
            pen = -1;
        };

        text _tmp_41
        {
            name = "Diff_1";
            x1 = 66.6506105834464;
            y1 = 100.975;
            x2 = 66.6506105834464;
            y2 = 100.975;
            string = "Diff";
            fontname = "����";
            fontcolor = 153;
            fonttype = 2;
            fontsize = 2.5;
            fontratio = 1;
            fontslant = 0;
            fontstyle = 0;
            angle = 0;
            justify = LEFT;
            pen = -1;
        };

        text _tmp_42
        {
            name = "J";
            x1 = 83.5298507462687;
            y1 = 108.125;
            x2 = 83.5298507462687;
            y2 = 108.125;
            string = "J";
            fontname = "����";
            fontcolor = 153;
            fonttype = 2;
            fontsize = 2.5;
            fontratio = 1;
            fontslant = 0;
            fontstyle = 0;
            angle = 0;
            justify = LEFT;
            pen = -1;
        };

        text _tmp_43
        {
            name = "Dwg_2";
            x1 = 76.4450474898236;
            y1 = 100.975;
            x2 = 76.4450474898236;
            y2 = 100.975;
            string = "Dwg";
            fontname = "����";
            fontcolor = 153;
            fonttype = 2;
            fontsize = 2.5;
            fontratio = 1;
            fontslant = 0;
            fontstyle = 0;
            angle = 0;
            justify = LEFT;
            pen = -1;
        };

        text _tmp_44
        {
            name = "Diff_2";
            x1 = 87.6506105834464;
            y1 = 100.975;
            x2 = 87.6506105834464;
            y2 = 100.975;
            string = "Diff";
            fontname = "����";
            fontcolor = 153;
            fonttype = 2;
            fontsize = 2.5;
            fontratio = 1;
            fontslant = 0;
            fontstyle = 0;
            angle = 0;
            justify = LEFT;
            pen = -1;
        };

        text _tmp_45
        {
            name = "K";
            x1 = 104.451831750339;
            y1 = 108.125;
            x2 = 104.451831750339;
            y2 = 108.125;
            string = "K";
            fontname = "����";
            fontcolor = 153;
            fonttype = 2;
            fontsize = 2.5;
            fontratio = 1;
            fontslant = 0;
            fontstyle = 0;
            angle = 0;
            justify = LEFT;
            pen = -1;
        };

        text _tmp_46
        {
            name = "Dwg_3";
            x1 = 97.4450474898236;
            y1 = 100.975;
            x2 = 97.4450474898236;
            y2 = 100.975;
            string = "Dwg";
            fontname = "����";
            fontcolor = 153;
            fonttype = 2;
            fontsize = 2.5;
            fontratio = 1;
            fontslant = 0;
            fontstyle = 0;
            angle = 0;
            justify = LEFT;
            pen = -1;
        };

        text _tmp_47
        {
            name = "Diff_3";
            x1 = 108.650610583446;
            y1 = 100.975;
            x2 = 108.650610583446;
            y2 = 100.975;
            string = "Diff";
            fontname = "����";
            fontcolor = 153;
            fonttype = 2;
            fontsize = 2.5;
            fontratio = 1;
            fontslant = 0;
            fontstyle = 0;
            angle = 0;
            justify = LEFT;
            pen = -1;
        };

        text _tmp_48
        {
            name = "L";
            x1 = 125.529850746269;
            y1 = 108.125;
            x2 = 125.529850746269;
            y2 = 108.125;
            string = "L";
            fontname = "����";
            fontcolor = 153;
            fonttype = 2;
            fontsize = 2.5;
            fontratio = 1;
            fontslant = 0;
            fontstyle = 0;
            angle = 0;
            justify = LEFT;
            pen = -1;
        };

        text _tmp_49
        {
            name = "Dwg_4";
            x1 = 118.445047489824;
            y1 = 100.975;
            x2 = 118.445047489824;
            y2 = 100.975;
            string = "Dwg";
            fontname = "����";
            fontcolor = 153;
            fonttype = 2;
            fontsize = 2.5;
            fontratio = 1;
            fontslant = 0;
            fontstyle = 0;
            angle = 0;
            justify = LEFT;
            pen = -1;
        };

        text _tmp_50
        {
            name = "Diff_4";
            x1 = 129.650610583446;
            y1 = 100.975;
            x2 = 129.650610583446;
            y2 = 100.975;
            string = "Diff";
            fontname = "����";
            fontcolor = 153;
            fonttype = 2;
            fontsize = 2.5;
            fontratio = 1;
            fontslant = 0;
            fontstyle = 0;
            angle = 0;
            justify = LEFT;
            pen = -1;
        };

        text _tmp_51
        {
            name = "M";
            x1 = 146.902985074627;
            y1 = 108.125;
            x2 = 146.902985074627;
            y2 = 108.125;
            string = "M";
            fontname = "����";
            fontcolor = 153;
            fonttype = 2;
            fontsize = 2.5;
            fontratio = 1;
            fontslant = 0;
            fontstyle = 0;
            angle = 0;
            justify = LEFT;
            pen = -1;
        };

        text _tmp_52
        {
            name = "Dwg_5";
            x1 = 139.445047489824;
            y1 = 100.975;
            x2 = 139.445047489824;
            y2 = 100.975;
            string = "Dwg";
            fontname = "����";
            fontcolor = 153;
            fonttype = 2;
            fontsize = 2.5;
            fontratio = 1;
            fontslant = 0;
            fontstyle = 0;
            angle = 0;
            justify = LEFT;
            pen = -1;
        };

        text _tmp_53
        {
            name = "Diff_5";
            x1 = 150.650610583446;
            y1 = 100.975;
            x2 = 150.650610583446;
            y2 = 100.975;
            string = "Diff";
            fontname = "����";
            fontcolor = 153;
            fonttype = 2;
            fontsize = 2.5;
            fontratio = 1;
            fontslant = 0;
            fontstyle = 0;
            angle = 0;
            justify = LEFT;
            pen = -1;
        };

        text _tmp_54
        {
            name = "N";
            x1 = 167.462008141113;
            y1 = 108.125;
            x2 = 167.462008141113;
            y2 = 108.125;
            string = "N";
            fontname = "����";
            fontcolor = 153;
            fonttype = 2;
            fontsize = 2.5;
            fontratio = 1;
            fontslant = 0;
            fontstyle = 0;
            angle = 0;
            justify = LEFT;
            pen = -1;
        };

        text _tmp_55
        {
            name = "Dwg_6";
            x1 = 160.445047489824;
            y1 = 100.975;
            x2 = 160.445047489824;
            y2 = 100.975;
            string = "Dwg";
            fontname = "����";
            fontcolor = 153;
            fonttype = 2;
            fontsize = 2.5;
            fontratio = 1;
            fontslant = 0;
            fontstyle = 0;
            angle = 0;
            justify = LEFT;
            pen = -1;
        };

        text _tmp_56
        {
            name = "Diff_6";
            x1 = 171.650610583446;
            y1 = 100.975;
            x2 = 171.650610583446;
            y2 = 100.975;
            string = "Diff";
            fontname = "����";
            fontcolor = 153;
            fonttype = 2;
            fontsize = 2.5;
            fontratio = 1;
            fontslant = 0;
            fontstyle = 0;
            angle = 0;
            justify = LEFT;
            pen = -1;
        };

        text _tmp_57
        {
            name = "Dwg. No.";
            x1 = 181.810040705563;
            y1 = 107.125;
            x2 = 181.810040705563;
            y2 = 107.125;
            string = "Dwg. No.";
            fontname = "����";
            fontcolor = 153;
            fonttype = 2;
            fontsize = 2.5;
            fontratio = 1;
            fontslant = 0;
            fontstyle = 0;
            angle = 0;
            justify = LEFT;
            pen = -1;
        };

        text _tmp_58
        {
            name = "(Rev. No.)";
            x1 = 181.107869742198;
            y1 = 101.975;
            x2 = 181.107869742198;
            y2 = 101.975;
            string = "(Rev. No.)";
            fontname = "����";
            fontcolor = 153;
            fonttype = 2;
            fontsize = 2.5;
            fontratio = 1;
            fontslant = 0;
            fontstyle = 0;
            angle = 0;
            justify = LEFT;
            pen = -1;
        };

        lineorarc _tmp_114
        {
            name = "LineOrArc_7";
            x1 = 10;
            y1 = 77.2;
            x2 = 32;
            y2 = 62.9;
            pen = -1;
            color = 153;
            linetype = 1;
            linewidth = 1;
            bulge = 0;
        };

        text _tmp_115
        {
            name = "Text";
            x1 = 21.4923215712929;
            y1 = 72.375;
            x2 = 21.4923215712929;
            y2 = 72.375;
            string = "Mark";
            fontname = "����";
            fontcolor = 153;
            fonttype = 2;
            fontsize = 2.5;
            fontratio = 1;
            fontslant = 0;
            fontstyle = 0;
            angle = 0;
            justify = LEFT;
            pen = -1;
        };

        text _tmp_116
        {
            name = "Text_1";
            x1 = 10.5547395001152;
            y1 = 65.225;
            x2 = 10.5547395001152;
            y2 = 65.225;
            string = "�����ȣ";
            fontname = "����";
            fontcolor = 153;
            fonttype = 2;
            fontsize = 2.5;
            fontratio = 1;
            fontslant = 0;
            fontstyle = 0;
            angle = 0;
            justify = LEFT;
            pen = -1;
        };

        text _tmp_117
        {
            name = "Text_2";
            x1 = 41.4874491180461;
            y1 = 72.375;
            x2 = 41.4874491180461;
            y2 = 72.375;
            string = "O";
            fontname = "����";
            fontcolor = 153;
            fonttype = 2;
            fontsize = 2.5;
            fontratio = 1;
            fontslant = 0;
            fontstyle = 0;
            angle = 0;
            justify = LEFT;
            pen = -1;
        };

        text _tmp_118
        {
            name = "Text_3";
            x1 = 34.4450474898236;
            y1 = 65.225;
            x2 = 34.4450474898236;
            y2 = 65.225;
            string = "Dwg";
            fontname = "����";
            fontcolor = 153;
            fonttype = 2;
            fontsize = 2.5;
            fontratio = 1;
            fontslant = 0;
            fontstyle = 0;
            angle = 0;
            justify = LEFT;
            pen = -1;
        };

        text _tmp_119
        {
            name = "Text_4";
            x1 = 45.6506105834464;
            y1 = 65.225;
            x2 = 45.6506105834464;
            y2 = 65.225;
            string = "Diff";
            fontname = "����";
            fontcolor = 153;
            fonttype = 2;
            fontsize = 2.5;
            fontratio = 1;
            fontslant = 0;
            fontstyle = 0;
            angle = 0;
            justify = LEFT;
            pen = -1;
        };

        text _tmp_120
        {
            name = "Text_5";
            x1 = 62.4586160108548;
            y1 = 72.375;
            x2 = 62.4586160108548;
            y2 = 72.375;
            string = "P";
            fontname = "����";
            fontcolor = 153;
            fonttype = 2;
            fontsize = 2.5;
            fontratio = 1;
            fontslant = 0;
            fontstyle = 0;
            angle = 0;
            justify = LEFT;
            pen = -1;
        };

        text _tmp_121
        {
            name = "Text_6";
            x1 = 55.4450474898236;
            y1 = 65.225;
            x2 = 55.4450474898236;
            y2 = 65.225;
            string = "Dwg";
            fontname = "����";
            fontcolor = 153;
            fonttype = 2;
            fontsize = 2.5;
            fontratio = 1;
            fontslant = 0;
            fontstyle = 0;
            angle = 0;
            justify = LEFT;
            pen = -1;
        };

        text _tmp_122
        {
            name = "Text_7";
            x1 = 66.6506105834464;
            y1 = 65.225;
            x2 = 66.6506105834464;
            y2 = 65.225;
            string = "Diff";
            fontname = "����";
            fontcolor = 153;
            fonttype = 2;
            fontsize = 2.5;
            fontratio = 1;
            fontslant = 0;
            fontstyle = 0;
            angle = 0;
            justify = LEFT;
            pen = -1;
        };

        text _tmp_123
        {
            name = "Text_8";
            x1 = 83.5298507462687;
            y1 = 72.375;
            x2 = 83.5298507462687;
            y2 = 72.375;
            string = "R";
            fontname = "����";
            fontcolor = 153;
            fonttype = 2;
            fontsize = 2.5;
            fontratio = 1;
            fontslant = 0;
            fontstyle = 0;
            angle = 0;
            justify = LEFT;
            pen = -1;
        };

        text _tmp_124
        {
            name = "Text_9";
            x1 = 76.4450474898236;
            y1 = 65.225;
            x2 = 76.4450474898236;
            y2 = 65.225;
            string = "Dwg";
            fontname = "����";
            fontcolor = 153;
            fonttype = 2;
            fontsize = 2.5;
            fontratio = 1;
            fontslant = 0;
            fontstyle = 0;
            angle = 0;
            justify = LEFT;
            pen = -1;
        };

        text _tmp_125
        {
            name = "Text_10";
            x1 = 87.6506105834464;
            y1 = 65.225;
            x2 = 87.6506105834464;
            y2 = 65.225;
            string = "Diff";
            fontname = "����";
            fontcolor = 153;
            fonttype = 2;
            fontsize = 2.5;
            fontratio = 1;
            fontslant = 0;
            fontstyle = 0;
            angle = 0;
            justify = LEFT;
            pen = -1;
        };

        text _tmp_126
        {
            name = "Text_11";
            x1 = 104.451831750339;
            y1 = 72.375;
            x2 = 104.451831750339;
            y2 = 72.375;
            string = "S";
            fontname = "����";
            fontcolor = 153;
            fonttype = 2;
            fontsize = 2.5;
            fontratio = 1;
            fontslant = 0;
            fontstyle = 0;
            angle = 0;
            justify = LEFT;
            pen = -1;
        };

        text _tmp_127
        {
            name = "Text_12";
            x1 = 97.4450474898236;
            y1 = 65.225;
            x2 = 97.4450474898236;
            y2 = 65.225;
            string = "Dwg";
            fontname = "����";
            fontcolor = 153;
            fonttype = 2;
            fontsize = 2.5;
            fontratio = 1;
            fontslant = 0;
            fontstyle = 0;
            angle = 0;
            justify = LEFT;
            pen = -1;
        };

        text _tmp_128
        {
            name = "Text_13";
            x1 = 108.650610583446;
            y1 = 65.225;
            x2 = 108.650610583446;
            y2 = 65.225;
            string = "Diff";
            fontname = "����";
            fontcolor = 153;
            fonttype = 2;
            fontsize = 2.5;
            fontratio = 1;
            fontslant = 0;
            fontstyle = 0;
            angle = 0;
            justify = LEFT;
            pen = -1;
        };

        text _tmp_129
        {
            name = "Text_39";
            x1 = 125.529850746269;
            y1 = 72.375;
            x2 = 125.529850746269;
            y2 = 72.375;
            string = "T";
            fontname = "����";
            fontcolor = 153;
            fonttype = 2;
            fontsize = 2.5;
            fontratio = 1;
            fontslant = 0;
            fontstyle = 0;
            angle = 0;
            justify = LEFT;
            pen = -1;
        };

        text _tmp_130
        {
            name = "Text_40";
            x1 = 118.445047489824;
            y1 = 65.225;
            x2 = 118.445047489824;
            y2 = 65.225;
            string = "Dwg";
            fontname = "����";
            fontcolor = 153;
            fonttype = 2;
            fontsize = 2.5;
            fontratio = 1;
            fontslant = 0;
            fontstyle = 0;
            angle = 0;
            justify = LEFT;
            pen = -1;
        };

        text _tmp_131
        {
            name = "Text_41";
            x1 = 129.650610583446;
            y1 = 65.225;
            x2 = 129.650610583446;
            y2 = 65.225;
            string = "Diff";
            fontname = "����";
            fontcolor = 153;
            fonttype = 2;
            fontsize = 2.5;
            fontratio = 1;
            fontslant = 0;
            fontstyle = 0;
            angle = 0;
            justify = LEFT;
            pen = -1;
        };

        text _tmp_132
        {
            name = "Text_42";
            x1 = 146.902985074627;
            y1 = 72.375;
            x2 = 146.902985074627;
            y2 = 72.375;
            string = "U";
            fontname = "����";
            fontcolor = 153;
            fonttype = 2;
            fontsize = 2.5;
            fontratio = 1;
            fontslant = 0;
            fontstyle = 0;
            angle = 0;
            justify = LEFT;
            pen = -1;
        };

        text _tmp_133
        {
            name = "Text_43";
            x1 = 139.445047489824;
            y1 = 65.225;
            x2 = 139.445047489824;
            y2 = 65.225;
            string = "Dwg";
            fontname = "����";
            fontcolor = 153;
            fonttype = 2;
            fontsize = 2.5;
            fontratio = 1;
            fontslant = 0;
            fontstyle = 0;
            angle = 0;
            justify = LEFT;
            pen = -1;
        };

        text _tmp_134
        {
            name = "Text_44";
            x1 = 150.650610583446;
            y1 = 65.225;
            x2 = 150.650610583446;
            y2 = 65.225;
            string = "Diff";
            fontname = "����";
            fontcolor = 153;
            fonttype = 2;
            fontsize = 2.5;
            fontratio = 1;
            fontslant = 0;
            fontstyle = 0;
            angle = 0;
            justify = LEFT;
            pen = -1;
        };

        text _tmp_135
        {
            name = "Text_45";
            x1 = 167.462008141113;
            y1 = 72.375;
            x2 = 167.462008141113;
            y2 = 72.375;
            string = "V";
            fontname = "����";
            fontcolor = 153;
            fonttype = 2;
            fontsize = 2.5;
            fontratio = 1;
            fontslant = 0;
            fontstyle = 0;
            angle = 0;
            justify = LEFT;
            pen = -1;
        };

        text _tmp_136
        {
            name = "Text_46";
            x1 = 160.445047489824;
            y1 = 65.225;
            x2 = 160.445047489824;
            y2 = 65.225;
            string = "Dwg";
            fontname = "����";
            fontcolor = 153;
            fonttype = 2;
            fontsize = 2.5;
            fontratio = 1;
            fontslant = 0;
            fontstyle = 0;
            angle = 0;
            justify = LEFT;
            pen = -1;
        };

        text _tmp_137
        {
            name = "Text_47";
            x1 = 171.650610583446;
            y1 = 65.225;
            x2 = 171.650610583446;
            y2 = 65.225;
            string = "Diff";
            fontname = "����";
            fontcolor = 153;
            fonttype = 2;
            fontsize = 2.5;
            fontratio = 1;
            fontslant = 0;
            fontstyle = 0;
            angle = 0;
            justify = LEFT;
            pen = -1;
        };

        text _tmp_138
        {
            name = "Text_48";
            x1 = 181.810040705563;
            y1 = 71.375;
            x2 = 181.810040705563;
            y2 = 71.375;
            string = "Dwg. No.";
            fontname = "����";
            fontcolor = 153;
            fonttype = 2;
            fontsize = 2.5;
            fontratio = 1;
            fontslant = 0;
            fontstyle = 0;
            angle = 0;
            justify = LEFT;
            pen = -1;
        };

        text _tmp_139
        {
            name = "Text_49";
            x1 = 181.107869742198;
            y1 = 66.225;
            x2 = 181.107869742198;
            y2 = 66.225;
            string = "(Rev. No.)";
            fontname = "����";
            fontcolor = 153;
            fonttype = 2;
            fontsize = 2.5;
            fontratio = 1;
            fontslant = 0;
            fontstyle = 0;
            angle = 0;
            justify = LEFT;
            pen = -1;
        };

        lineorarc _tmp_252
        {
            name = "LineOrArc_i32";
            x1 = 170;
            y1 = 41.45;
            x2 = 170;
            y2 = 5.7;
            pen = -1;
            color = 153;
            linetype = 1;
            linewidth = 1;
            bulge = 0;
        };

        lineorarc _tmp_1053
        {
            name = "LineOrArc_i68";
            x1 = 200;
            y1 = 134.4;
            x2 = 10;
            y2 = 134.4;
            pen = -1;
            color = 153;
            linetype = 1;
            linewidth = 1;
            bulge = 0;
        };

        group _tmp_107
        {
            name = "Group";

            lineorarc _tmp_56
            {
                name = "LineOrArc_i0";
                x1 = 200;
                y1 = 120.1;
                x2 = 10;
                y2 = 120.1;
                pen = -1;
                color = 153;
                linetype = 1;
                linewidth = 1;
                bulge = 0;
            };

            lineorarc _tmp_57
            {
                name = "LineOrArc_i1";
                x1 = 200;
                y1 = 112.95;
                x2 = 10;
                y2 = 112.95;
                pen = -1;
                color = 153;
                linetype = 1;
                linewidth = 1;
                bulge = 0;
            };

            lineorarc _tmp_58
            {
                name = "LineOrArc_i2";
                x1 = 200;
                y1 = 105.8;
                x2 = 32;
                y2 = 105.8;
                pen = -1;
                color = 153;
                linetype = 1;
                linewidth = 1;
                bulge = 0;
            };

            lineorarc _tmp_59
            {
                name = "LineOrArc_i3";
                x1 = 200;
                y1 = 84.3500000000001;
                x2 = 10;
                y2 = 84.3500000000001;
                pen = -1;
                color = 153;
                linetype = 1;
                linewidth = 1;
                bulge = 0;
            };

            lineorarc _tmp_60
            {
                name = "LineOrArc_i4";
                x1 = 200;
                y1 = 77.2;
                x2 = 10;
                y2 = 77.2;
                pen = -1;
                color = 153;
                linetype = 1;
                linewidth = 1;
                bulge = 0;
            };

            lineorarc _tmp_61
            {
                name = "LineOrArc_i5";
                x1 = 200;
                y1 = 70.05;
                x2 = 32;
                y2 = 70.05;
                pen = -1;
                color = 153;
                linetype = 1;
                linewidth = 1;
                bulge = 0;
            };

            lineorarc _tmp_62
            {
                name = "LineOrArc_i6";
                x1 = 200;
                y1 = 62.9;
                x2 = 10;
                y2 = 62.9;
                pen = -1;
                color = 153;
                linetype = 1;
                linewidth = 1;
                bulge = 0;
            };

            lineorarc _tmp_63
            {
                name = "LineOrArc_i7";
                x1 = 200;
                y1 = 55.75;
                x2 = 10;
                y2 = 55.75;
                pen = -1;
                color = 153;
                linetype = 1;
                linewidth = 1;
                bulge = 0;
            };

            lineorarc _tmp_64
            {
                name = "LineOrArc_i8";
                x1 = 200;
                y1 = 48.6;
                x2 = 10;
                y2 = 48.6;
                pen = -1;
                color = 153;
                linetype = 1;
                linewidth = 1;
                bulge = 0;
            };

            lineorarc _tmp_65
            {
                name = "LineOrArc_i9";
                x1 = 179;
                y1 = 134.4;
                x2 = 179;
                y2 = 41.45;
                pen = -1;
                color = 153;
                linetype = 1;
                linewidth = 1;
                bulge = 0;
            };

            lineorarc _tmp_66
            {
                name = "LineOrArc_i10";
                x1 = 158;
                y1 = 134.4;
                x2 = 158;
                y2 = 41.45;
                pen = -1;
                color = 153;
                linetype = 1;
                linewidth = 1;
                bulge = 0;
            };

            lineorarc _tmp_67
            {
                name = "LineOrArc_i11";
                x1 = 137;
                y1 = 134.4;
                x2 = 137;
                y2 = 41.45;
                pen = -1;
                color = 153;
                linetype = 1;
                linewidth = 1;
                bulge = 0;
            };

            lineorarc _tmp_68
            {
                name = "LineOrArc_i12";
                x1 = 116;
                y1 = 134.4;
                x2 = 116;
                y2 = 41.45;
                pen = -1;
                color = 153;
                linetype = 1;
                linewidth = 1;
                bulge = 0;
            };

            lineorarc _tmp_69
            {
                name = "LineOrArc_i13";
                x1 = 95;
                y1 = 134.4;
                x2 = 95;
                y2 = 41.45;
                pen = -1;
                color = 153;
                linetype = 1;
                linewidth = 1;
                bulge = 0;
            };

            lineorarc _tmp_70
            {
                name = "LineOrArc_i14";
                x1 = 74;
                y1 = 134.4;
                x2 = 74;
                y2 = 41.45;
                pen = -1;
                color = 153;
                linetype = 1;
                linewidth = 1;
                bulge = 0;
            };

            lineorarc _tmp_71
            {
                name = "LineOrArc_i15";
                x1 = 53;
                y1 = 134.4;
                x2 = 53;
                y2 = 41.45;
                pen = -1;
                color = 153;
                linetype = 1;
                linewidth = 1;
                bulge = 0;
            };

            lineorarc _tmp_72
            {
                name = "LineOrArc_i16";
                x1 = 32;
                y1 = 134.4;
                x2 = 32;
                y2 = 41.45;
                pen = -1;
                color = 153;
                linetype = 1;
                linewidth = 1;
                bulge = 0;
            };

            lineorarc _tmp_73
            {
                name = "LineOrArc_i17";
                x1 = 44;
                y1 = 134.4;
                x2 = 44;
                y2 = 112.95;
                pen = -1;
                color = 153;
                linetype = 1;
                linewidth = 1;
                bulge = 0;
            };

            lineorarc _tmp_74
            {
                name = "LineOrArc_i18";
                x1 = 44;
                y1 = 105.8;
                x2 = 44;
                y2 = 77.2;
                pen = -1;
                color = 153;
                linetype = 1;
                linewidth = 1;
                bulge = 0;
            };

            lineorarc _tmp_75
            {
                name = "LineOrArc_i19";
                x1 = 44;
                y1 = 70.0500000000001;
                x2 = 44;
                y2 = 41.45;
                pen = -1;
                color = 153;
                linetype = 1;
                linewidth = 1;
                bulge = 0;
            };

            lineorarc _tmp_76
            {
                name = "LineOrArc_i20";
                x1 = 65;
                y1 = 134.4;
                x2 = 65;
                y2 = 112.95;
                pen = -1;
                color = 153;
                linetype = 1;
                linewidth = 1;
                bulge = 0;
            };

            lineorarc _tmp_77
            {
                name = "LineOrArc_i21";
                x1 = 65;
                y1 = 105.8;
                x2 = 65;
                y2 = 77.2;
                pen = -1;
                color = 153;
                linetype = 1;
                linewidth = 1;
                bulge = 0;
            };

            lineorarc _tmp_78
            {
                name = "LineOrArc_i22";
                x1 = 65;
                y1 = 70.0500000000001;
                x2 = 65;
                y2 = 41.45;
                pen = -1;
                color = 153;
                linetype = 1;
                linewidth = 1;
                bulge = 0;
            };

            lineorarc _tmp_79
            {
                name = "LineOrArc_i23";
                x1 = 86;
                y1 = 134.4;
                x2 = 86;
                y2 = 112.95;
                pen = -1;
                color = 153;
                linetype = 1;
                linewidth = 1;
                bulge = 0;
            };

            lineorarc _tmp_80
            {
                name = "LineOrArc_i24";
                x1 = 86;
                y1 = 105.8;
                x2 = 86;
                y2 = 77.2;
                pen = -1;
                color = 153;
                linetype = 1;
                linewidth = 1;
                bulge = 0;
            };

            lineorarc _tmp_81
            {
                name = "LineOrArc_i25";
                x1 = 86;
                y1 = 70.0500000000001;
                x2 = 86;
                y2 = 41.45;
                pen = -1;
                color = 153;
                linetype = 1;
                linewidth = 1;
                bulge = 0;
            };

            lineorarc _tmp_82
            {
                name = "LineOrArc_i26";
                x1 = 107;
                y1 = 134.4;
                x2 = 107;
                y2 = 112.95;
                pen = -1;
                color = 153;
                linetype = 1;
                linewidth = 1;
                bulge = 0;
            };

            lineorarc _tmp_83
            {
                name = "LineOrArc_i27";
                x1 = 107;
                y1 = 105.8;
                x2 = 107;
                y2 = 77.2;
                pen = -1;
                color = 153;
                linetype = 1;
                linewidth = 1;
                bulge = 0;
            };

            lineorarc _tmp_84
            {
                name = "LineOrArc_i28";
                x1 = 107;
                y1 = 70.0500000000001;
                x2 = 107;
                y2 = 41.45;
                pen = -1;
                color = 153;
                linetype = 1;
                linewidth = 1;
                bulge = 0;
            };

            lineorarc _tmp_85
            {
                name = "LineOrArc_i29";
                x1 = 128;
                y1 = 134.4;
                x2 = 128;
                y2 = 112.95;
                pen = -1;
                color = 153;
                linetype = 1;
                linewidth = 1;
                bulge = 0;
            };

            lineorarc _tmp_86
            {
                name = "LineOrArc_i30";
                x1 = 128;
                y1 = 105.8;
                x2 = 128;
                y2 = 77.2;
                pen = -1;
                color = 153;
                linetype = 1;
                linewidth = 1;
                bulge = 0;
            };

            lineorarc _tmp_87
            {
                name = "LineOrArc_i31";
                x1 = 128;
                y1 = 70.0500000000001;
                x2 = 128;
                y2 = 41.45;
                pen = -1;
                color = 153;
                linetype = 1;
                linewidth = 1;
                bulge = 0;
            };

            lineorarc _tmp_88
            {
                name = "LineOrArc_i32";
                x1 = 149;
                y1 = 134.4;
                x2 = 149;
                y2 = 112.95;
                pen = -1;
                color = 153;
                linetype = 1;
                linewidth = 1;
                bulge = 0;
            };

            lineorarc _tmp_89
            {
                name = "LineOrArc_i33";
                x1 = 149;
                y1 = 105.8;
                x2 = 149;
                y2 = 77.2;
                pen = -1;
                color = 153;
                linetype = 1;
                linewidth = 1;
                bulge = 0;
            };

            lineorarc _tmp_90
            {
                name = "LineOrArc_i34";
                x1 = 149;
                y1 = 70.0500000000001;
                x2 = 149;
                y2 = 41.45;
                pen = -1;
                color = 153;
                linetype = 1;
                linewidth = 1;
                bulge = 0;
            };

            lineorarc _tmp_91
            {
                name = "LineOrArc_i35";
                x1 = 170;
                y1 = 134.4;
                x2 = 170;
                y2 = 112.95;
                pen = -1;
                color = 153;
                linetype = 1;
                linewidth = 1;
                bulge = 0;
            };

            lineorarc _tmp_92
            {
                name = "LineOrArc_i36";
                x1 = 170;
                y1 = 105.8;
                x2 = 170;
                y2 = 77.2;
                pen = -1;
                color = 153;
                linetype = 1;
                linewidth = 1;
                bulge = 0;
            };

            lineorarc _tmp_93
            {
                name = "LineOrArc_i37";
                x1 = 170;
                y1 = 70.05;
                x2 = 170;
                y2 = 41.45;
                pen = -1;
                color = 153;
                linetype = 1;
                linewidth = 1;
                bulge = 0;
            };

            lineorarc _tmp_94
            {
                name = "LineOrArc_i38";
                x1 = 170;
                y1 = 41.45;
                x2 = 170;
                y2 = 5.7;
                pen = -1;
                color = 153;
                linetype = 1;
                linewidth = 1;
                bulge = 0;
            };

            lineorarc _tmp_95
            {
                name = "LineOrArc_i39";
                x1 = 200;
                y1 = 5.7;
                x2 = 200;
                y2 = 134.4;
                pen = -1;
                color = 153;
                linetype = 1;
                linewidth = 1;
                bulge = 0;
            };

            lineorarc _tmp_96
            {
                name = "LineOrArc_i40";
                x1 = 200;
                y1 = 120.1;
                x2 = 10;
                y2 = 120.1;
                pen = -1;
                color = 153;
                linetype = 1;
                linewidth = 1;
                bulge = 0;
            };

            lineorarc _tmp_97
            {
                name = "LineOrArc_i41";
                x1 = 10;
                y1 = 134.4;
                x2 = 10;
                y2 = 5.7;
                pen = -1;
                color = 153;
                linetype = 1;
                linewidth = 1;
                bulge = 0;
            };

            polyline _tmp_98
            {
                name = "Polyline_i42";
                filled = FALSE;
                filltype = -1;
                color = 153;
                linetype = 1;
                linewidth = 1;
                pen = -1;

                lineorarc _tmp_99
                {
                    name = "LineOrArc_i43";
                    x1 = 0;
                    y1 = 5;
                    x2 = 0;
                    y2 = 0;
                    pen = -1;
                    color = 153;
                    linetype = 1;
                    linewidth = 1;
                    bulge = 0;
                };

                lineorarc _tmp_100
                {
                    name = "LineOrArc_i43";
                    x1 = 0;
                    y1 = 0;
                    x2 = 5;
                    y2 = 0;
                    pen = -1;
                    color = 153;
                    linetype = 1;
                    linewidth = 1;
                    bulge = 0;
                };
            };

            lineorarc _tmp_101
            {
                name = "LineOrArc_i43";
                x1 = 200;
                y1 = 127.25;
                x2 = 10;
                y2 = 127.25;
                pen = -1;
                color = 153;
                linetype = 1;
                linewidth = 1;
                bulge = 0;
            };

            lineorarc _tmp_102
            {
                name = "LineOrArc_i44";
                x1 = 200;
                y1 = 134.4;
                x2 = 10;
                y2 = 134.4;
                pen = -1;
                color = 153;
                linetype = 1;
                linewidth = 1;
                bulge = 0;
            };

            lineorarc _tmp_103
            {
                name = "LineOrArc_i45";
                x1 = 200;
                y1 = 5.7;
                x2 = 10;
                y2 = 5.7;
                pen = -1;
                color = 153;
                linetype = 1;
                linewidth = 1;
                bulge = 0;
            };

            lineorarc _tmp_104
            {
                name = "LineOrArc_i46";
                x1 = 200;
                y1 = 98.65;
                x2 = 10;
                y2 = 98.65;
                pen = -1;
                color = 153;
                linetype = 1;
                linewidth = 1;
                bulge = 0;
            };

            lineorarc _tmp_105
            {
                name = "LineOrArc_i47";
                x1 = 200;
                y1 = 91.5;
                x2 = 10;
                y2 = 91.5;
                pen = -1;
                color = 153;
                linetype = 1;
                linewidth = 1;
                bulge = 0;
            };

            lineorarc _tmp_106
            {
                name = "LineOrArc_i48";
                x1 = 200;
                y1 = 41.45;
                x2 = 10;
                y2 = 41.45;
                pen = -1;
                color = 153;
                linetype = 1;
                linewidth = 1;
                bulge = 0;
            };
        };
    };
};
